
    let arr = []
    for(let i = 0; i < 500; i++) {
      arr = arr.concat([{
        "id": "sadsa" + i,
        "name": "Through the Looking-Glass",
        "synopsis": "This book was converted from its physical edition to the digital format by a community of volunteers. You may find it for free on the web. Purchase of the Kindle edition includes wireless delivery.",
        "price": 4566,
        "size": "80*80cm",
        "material": "paper",
        "subjectMatter": "story",
        "user": "",
        "img": "https://images-cn.ssl-images-amazon.cn/images/I/41UttRffz9L.jpg",
        "details": "Helen Oxenbury’s ALICE’S ADVENTURES IN WONDERLAND set a new standard for contemporary editions of Lewis Carroll’s beloved classic. And now she has illustrated its companion, ALICE THROUGH THE LOOKING-GLASS, with equal intimacy, warmth, and charm. Here again is Alice, dressed in her bright blue jumper and ready for adventure like any modern child. All it takes is a bit of curiosity about the room reversed in the mirror and suddenly Alice is in the Looking-Glass world with all manner of comical and magical characters -Tweedledum and Tweedledee, the lion and the unicorn, and a whole game board of chess pieces come to life. On page after page, Helen Oxenbury’s incomparable line drawings, sepia illustrations, and full-color paintings give today’s children their own utterly accessible view into Lewis Carroll’s timeless nonsense"
      }, {
        "id": "N2SNIGIH" + i,
        "name": "Grimm's Fairy Tales",
        "synopsis": "This book was converted from its physical edition to the digital format by a community of volunteers. You may find it for free on the web. Purchase of the Kindle edition includes wireless delivery.",
        "price": 4566,
        "size": "40*40cm",
        "material": "paper",
        "subjectMatter": "story",
        "Specification": ['big', 'small'],
        "user": "",
        "img": "https://images-cn.ssl-images-amazon.cn/images/I/41SGXQDhMRL.jpg",
        "details": "Helen Oxenbury’s ALICE’S ADVENTURES IN WONDERLAND set a new standard for contemporary editions of Lewis Carroll’s beloved classic. And now she has illustrated its companion, ALICE THROUGH THE LOOKING-GLASS, with equal intimacy, warmth, and charm. Here again is Alice, dressed in her bright blue jumper and ready for adventure like any modern child. All it takes is a bit of curiosity about the room reversed in the mirror and suddenly Alice is in the Looking-Glass world with all manner of comical and magical characters -Tweedledum and Tweedledee, the lion and the unicorn, and a whole game board of chess pieces come to life. On page after page, Helen Oxenbury’s incomparable line drawings, sepia illustrations, and full-color paintings give today’s children their own utterly accessible view into Lewis Carroll’s timeless nonsense"
      },
      ])
    }

export default arr