// *.d.ts file
declare interface Window {
  Swiper: any;
}
